#include <iostream>
#include "ReadData.h"
int main(int argc, char *argv[]) 
{
	
	ReadData Data;
	Data.getData(argc, argv);


		
	return 0;
}