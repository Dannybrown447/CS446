/**cpp file for the ReadData ADT

 * @brief implementations of all the needed functions for the ADT
 * 
 * @author Daniel Brown
 * 
 * @details This impliments the functions declared in ReadData.h
 *    Given a configuration file and meta-data file it will capture all data
 *
 * @version 1.0
 */

#include <iostream>
#include <fstream>
#include <stack>
#include <queue>
#include <vector>
#include "ReadData.h"
#include <stdlib.h>
#include <algorithm>

//used to make it simpler for outputing to monitor and new line
using std::endl;
using std::cout;

/** deletes all spaces
  /*@pre a string exists to pass to function
  /*@post all spaces are deleted
  /*param str string to be checked for extra spaces
  */
std::string ReadData:: delSpaces(std::string &str) 
{
   str.erase(std::remove(str.begin(), str.end(), ' '), str.end());
   return str;
}

/** deletes unnecessary spaces
/*@pre a string exists to pass to function
/*@post all extra spaces are deleted
/*param str string to be checked for extra spaces
*/
std::string ReadData:: delUnnecessary(std::string &str)
{
    int size = str.length();
    for(int j = 0; j<=size; j++)
    {
        for(int i = 0; i <=j; i++)
        {
            if(str[i] == ' ' && str[i+1] == ' ')
            {
                str.erase(str.begin() + i);
            }
            else if(str[0]== ' ')
            {
                str.erase(str.begin());
            }
            else if(str[i] == '\0' && str[i-1]== ' ')
            {
                str.erase(str.end() - 1);
            }
        }
    }
    return str;
}

/** Searches vector for a string and returns -1 if not found
  /*@pre vector and string have been declared
  /*@post vector is searched and index returned 
  /*param string str string to search for
  /*  vector cycles to calculate times
  */
int ReadData:: searchVector(std::vector<cycleInfo> v, std::string str)
{
  int i = 0;
  while(i < v.size())
  {
    if(v[i].id == str)
      return i;
    else
      i++;
  }
  return -1;
}

/** Searches Data from config file for matching meta functions
  /*@pre config file has been read in
  /*@post config file is searched and if found index returned 
  /*param string str string to search for
  /*  vector cycles to calculate times
  */
int ReadData:: checkDescript(std::vector<cycleInfo> cycle, std::vector<cycleInfo>& data, std::string str)
{
  int runTime = 0;
  int index = -1;
   if(data.front().cycleTime >= 0)
    {
         index = searchVector(cycle, str);
         //checks if matching word is found from config
         if(index < 0)
          std::cerr << "No description from configuration file matching: " << str << ", skipping this process\n";

         runTime = cycle[index].cycleTime * data.front().cycleTime;
         data.erase(data.begin());
        }
        else
        {
          data.erase(data.begin());
          return -1;
        }
    return runTime;

  
}
  /** Gets Data from files and creates outputs based on the inputs
  /*@pre 
  /*@post all data is imported and errors handled 
  /*param int argc for command line operations
  /*  char*[] for command line operations
  */
bool ReadData:: getData(int argc, char *argv[])
{
  /**Variable Definitions**/
  std::queue<std::string> data;
  bool logToFile = false;
  bool logToMon = false;
  std::string word;
  std::string tempRead;
  std::string metaFileName;
  std::vector<cycleInfo> cycleType;
  std::string outFile;
  float versionNum = 0;

  //checks for command word arguments
	if(argc < 2)
	{
		std::cerr << " invalid number of command word files" << std::endl;
		return false; 
	}//ends if

	std::ifstream fin;
	std::string checkConfExt = ".conf";

  std::queue<std::string> errorQueue;

	for(int i = 1; i < argc; i++)//opens and checks all command word arguments
	{
		//checks the file extension to ensure its a conf file
		std::string commandwordName = argv[i];

		std:: size_t found = commandwordName.find(checkConfExt);

  		if(found == std::string::npos)
  		{	
  			std::cerr << "invalid file extension" << std::endl;
  			return false;
  		}

  		//if it is the correct file extension it will try to open the file
		fin.open(argv[i]);
    	if ( !fin.is_open())//tries to open files
    	{	
      		std::cerr<<"Could not open file" << std::endl;
      		return false;//if failed to open the program will close      
      }//ends if

      //gets first line to check if the file is empty before reading it all in
      getline(fin,word);
      data.push(word);
      while(!fin.eof())
      {
        
        getline(fin,word);

        //places data into a queue
        data.push(word);
      }

      fin.close();

      //checks if file is empty
      if(data.size() <= 1 )
      {
        std::cerr << "Empty Configuration File in file named: " << commandwordName <<std::endl;
        return false;
      }
      
        //deletes extra spaces
        delUnnecessary(data.front());
        if(data.front() == "Start Simulator Configuration File")
        {
          data.pop();
        }
        else
        {
          std::cerr << "Misspelling in first line, read in from " << commandwordName << endl;
          data.pop();
          errorQueue.push(data.front());
        }


        //go through data in the queue
       while(!data.empty())
       {
        //gets rid of unwanted spaces
        delUnnecessary(data.front());

        if(data.front() == "End Simulator Configuration File" && data.front()==data.back())
        {
          data.pop();
          break;
        }
        if(data.front() != "End Simulator Configuration File" && data.front()==data.back())
        {
          std::cerr <<"Misspelling in last line: '" << data.front() << "'\n";
          data.pop();
          errorQueue.push(data.front());
          break;
        }
          //checks for : to get cycle time
          found = data.front().find(":");       
          if(found == std::string::npos)
          {
              std::cerr << "Line missing ':' in line: '" << data.front() << "'" << endl;; 
              errorQueue.push(data.front());
              data.pop();
             
           }//ends if checking for :

           //ensures that there is a cycle time and not a blank entry
          if(data.front()[found] == '\0')
           {
            std::cerr << "Line missing expression after: " << data.front() << endl;
            data.pop();
           }//ends if 

          //if it is a valid entry and ':' is found it extracts first word 
          else
          {
            tempRead = data.front().substr(0,found+1);
          }//ends else assigning the first word to a string

          if(tempRead == "Version/Phase:")
          {
            //sets word to the value after :
            word = data.front().substr(found+2, std::string::npos);
            versionNum = stof(word);
            data.pop();
            
          }//ends version/phase check

          else if(tempRead == "File Path:")
          {
            //sets word to the value after :
            word = data.front().substr(found+2, std::string::npos);
            found = word.find(".mdf");
            if(found == std::string::npos)
            { 
              std::cerr << "Invalid Meta Data file extension, read in from file '" << commandwordName << "' aborted\n";
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              metaFileName = word;
              data.pop();
            }
          }//ends file path check

          else if(tempRead == "Processor cycle time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.id = "Processor";
            cycle.cycleTime = atoi((word).c_str());
            if(cycle.cycleTime <= 0)
            {
                std::cerr<< "Invalid cycle time on " << tempRead << endl;
                errorQueue.push(data.front());
                data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();
            }

          }//ends Processor check

          else if(tempRead == "Monitor display time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.cycleTime = atoi((word).c_str());
            cycle.id = "Monitor";
            if(cycle.cycleTime <= 0)
            {
              std::cerr << "Invalid cycle time on " << tempRead << endl;
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();
            }
          }//ends monitor check

          else if(tempRead == "Hard drive cycle time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.cycleTime = atoi((word).c_str());
            cycle.id = "hard drive";
            if(cycle.cycleTime <= 0)
            {
              std::cerr << "Invalid cycle time on " << tempRead << endl;
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();
            }
          }//ends Hard drive check

           else if(tempRead == "Printer cycle time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.cycleTime = atoi((word).c_str());
            cycle.id = "Printer";
            if(cycle.cycleTime <= 0)
            {
              std::cerr << "Invalid cycle time on " << tempRead << endl;
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();
            }
          }//ends Printer check

          else if(tempRead == "Keyboard cycle time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.cycleTime = atoi((word).c_str());
            cycle.id = "Keyboard";
            if(cycle.cycleTime <= 0)
            {
              std::cerr << "Invalid cycle time on " << tempRead << endl;
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();

            }
          }//ends keyboard check

          else if(tempRead == "Memory cycle time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.cycleTime = atoi((word).c_str());
            cycle.id = "Memory";
            if(cycle.cycleTime <= 0)
            {
              std::cerr << "Invalid cycle time on " << tempRead << endl;
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();
            }
          }//ends memory check

          else if(tempRead == "Mouse cycle time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.cycleTime = atoi((word).c_str());
            cycle.id = "Mouse";
            if(cycle.cycleTime <= 0)
            {
              std::cerr << "Invalid cycle time on " << tempRead << endl;
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();
            }
          }//ends mouse check

          else if(tempRead == "Speaker cycle time (msec):")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            cycle.cycleTime = atoi((word).c_str());
            cycle.id = "Speaker";
            if(cycle.cycleTime <= 0)
            {
              std::cerr << "Invalid cycle time on " << tempRead << endl;
              errorQueue.push(data.front());
              data.pop();
            }
            else
            {
              cycleType.push_back(cycle);
              data.pop();
            }
          }//ends speaker check

          else if(tempRead == "Log:")
          {
            //sets word to the value after : 
            word = data.front().substr(found+2, std::string::npos);
            if(word == "Log to Both")
            {
              logToFile = true;
              logToMon = true;
              data.pop();
            }
            else if (word == "Log to File")
            {
              logToFile = true;
              logToMon = false;
              data.pop();
            }
            else if(word == "Log to Monitor")
            {
              logToMon = true;
              logToFile = false;
              data.pop();
            }
            else
            {
              std::cerr <<"Misspelling or missing item in line: '" << data.front() << "'\n";
              errorQueue.push(data.front());
              data.pop();
            }
          }//ends log check

           else if(tempRead == "Log File Path:")
          {
            //sets word to the value after : 
            outFile = data.front().substr(found+2, std::string::npos);
            data.pop();
            
          }//ends log file path check

          else
          {
            std::cerr << "Misspelling in line '" << data.front() <<"'\n";
            errorQueue.push(data.front()); 
            data.pop();
        }//first word error check
      }//ends while data isnt empty
        //function calls to output Config file data and read in and output Meta Data 
        outputCfgData(cycleType,logToFile,logToMon, outFile);
        outputMeta(getMetaData(metaFileName,cycleType),logToFile, logToMon, outFile);
        cout << "\nEnd of file: " << commandwordName << endl << endl;
        if(!errorQueue.empty())
        {
          cout<< "There are a total of: " << errorQueue.size() << " line errors\n" << endl;
        }
     }//ends for

//to give the number of errors in the file


     
}//ends getData

  /** Gets Data from files and creates outputs based on the inputs
  /*@pre 
  /*@post all data is imported and errors handled 
  /*param string meta name of the file
  /*  vector cycles to calculate times
  */
std::vector<cycleInfo> ReadData:: getMetaData(std::string meta, std::vector<cycleInfo>& cycles)
{

  /**Variable Definitions**/
  std::ifstream fin;
  std::vector<cycleInfo> metaCycles;
  std::vector<cycleInfo> data;
  std::string tempRead;
  std:: stack<cycleInfo> startStack;
  std:: stack<cycleInfo> endStack;
  std::string startCheck = "StartProgramMeta-DataCode:";
  std::string word;
  int index = 0;
  int i = 0;
  cycleInfo cycle;
  std:: size_t found;
  


 //open file check
  fin.open(meta);
  if ( !fin.is_open())
  { 
    std::cerr<<"Could not open file" << std::endl;
    exit (EXIT_FAILURE);
 
  }//ends if

  //Gets data from file and checks if it is empty
  getline(fin,tempRead);
  //removes spaces
  delSpaces(tempRead);

  if(tempRead != startCheck)
      {
        std::cerr <<"Misspelled or missing first/last line Program ending" << endl;
        exit(EXIT_FAILURE);
      }
      //reads in data until end of file
      while(!fin.eof())
      {
        //gets data from file until ')' is reached
        getline(fin,cycle.id,')');
        
        //gets cycle time for each meta data cycle
        fin>> cycle.cycleTime;
        //checks if there is no cycle time, if there isn't it ends the program
        if(fin.fail())
        {
          //searches for End of meta file and if it isnt there it ends the program
          found = cycle.id.find('E');
          if(found != std::string::npos)
          {
              break;
          }
          //outputs which number descriptor has an issue if any
          std::cerr << "Descriptor number " << i+1 << " has an error, program aborted" << endl;
          exit(EXIT_FAILURE);
        }
        //puts data into a vector
        data.push_back(cycle);
        i++;
            
      }
      fin.close();
      //if it is an empty file it will end the program
      if(data.size() <= 1 )
      {
        std::cerr << "Empty Meta File in file named: " << meta <<std::endl;
        exit(EXIT_FAILURE);
      }


  while(!data.empty())
  {
      //deletes extra spaces to make data easier to go through
      delSpaces(data.front().id);

      //searches for '(' for each descriptor
      found = data.front().id.find('(');

      if(found == std::string::npos)
      { 
        std::cerr << "Missing '('" << std::endl;
        exit(EXIT_FAILURE);
      }
      //sets the string from one char before '(' to get entire descriptor
      word = data.front().id.substr(found-1, std::string::npos);
      
      /**Organizes data and puts it into a vector**/

      if(word == "S(start") 
      {
       if(data.front().cycleTime == 0)
       {
         startStack.push(data.front());
         data.erase(data.begin());
       }
       else
       {
         std::cerr << "Invalid cycle time for: " << word << endl;
         data.erase(data.begin());
       }
       
      }

     else if(word == "S(end")
     {
       if(data.front().cycleTime == 0)
       {
        if(!startStack.empty())
        { 
            startStack.pop();
        }
        else
        {
          std::cerr << "Warning: Meta file contains " << word << ") without a matching S(start)\n";
        }

         data.erase(data.begin());
       }
       else
       {
         std::cerr << "Invalid cycle time for: " << word << ")" << endl;
         data.erase(data.begin());
       }
       
     }
      else if(word == "A(start") 
      {
        if(data.front().cycleTime == 0)
        {
          endStack.push(data.front());
          data.erase(data.begin());

        }
        else
        {
          std::cerr << "Error in cycle time for: " << word << ")" << endl;
          data.erase(data.begin());
        }
        
      }   
      else if(word == "A(end")
      {
        if(data.front().cycleTime == 0)
        {
          if(!endStack.empty())
          {
              endStack.pop();
          }
          else
          {
            std::cerr << "Warning: Meta file contains " << word << ") without a matching A(start)\n";
          }
          data.erase(data.begin());
        }
        else
        {
          std::cerr << "Error in cycle time for: " << word << ")" << endl;
          data.erase(data.begin());
        }
        
      } 
      else if(word == "M(allocate" || word == "M(block")
      {
          cycle.cycleTime = checkDescript(cycles,data,"Memory");
          if(cycle.cycleTime <= 0)
            std::cerr << "Error in cycle time for: " << word << ")" << endl;
          else
          {
            cycle.id = word;
            metaCycles.push_back(cycle);
          }
      }

      else if(word == "P(run")
      {
          cycle.cycleTime = checkDescript(cycles,data,"Processor");
          if(cycle.cycleTime <= 0)
            std::cerr << "Error in cycle time for: " << word << ")" << endl;
          else
          {
            cycle.id = word;
            metaCycles.push_back(cycle);
          }
          
      }
      else if(word == "I(harddrive" || word == "O(harddrive")
      {
        cycle.cycleTime = checkDescript(cycles,data,"hard drive");
          if(cycle.cycleTime <= 0)
            std::cerr << "Error in cycle time for: " << word << ")" << endl;
          else
          {
            cycle.id = word;
            metaCycles.push_back(cycle);
          }
          
      }
      else if(word == "I(mouse")
      {
          cycle.cycleTime = checkDescript(cycles,data,"Mouse");
          if(cycle.cycleTime <= 0)
            std::cerr << "Error in cycle time for: " << word << ")" << endl;
          else
          {
            cycle.id = word;
            metaCycles.push_back(cycle);
          }
      }
      else if(word == "I(keyboard")
      {
        cycle.cycleTime = checkDescript(cycles,data,"Keyboard");
        if(cycle.cycleTime <= 0)
          std::cerr << "Error in cycle time for: " << word << ")" << endl;
        else
        {
          cycle.id = word;
          metaCycles.push_back(cycle);
        }
      }
      else if(word == "O(monitor")// word == "O(speaker" )
      {
        cycle.cycleTime = checkDescript(cycles,data,"Monitor");
        if(cycle.cycleTime <= 0)
          std::cerr << "Error in cycle time for: " << word << ")" << endl;
        else
        {
          cycle.id = word;
          metaCycles.push_back(cycle);
        }
      }
      else if(word == "O(speaker")
      {
        cycle.cycleTime = checkDescript(cycles,data,"Speaker");
        if(cycle.cycleTime <= 0)
          std::cerr << "Error in cycle time for: " << word << ")" << endl;
        else
        {
          cycle.id = word;
          metaCycles.push_back(cycle);
        }
      }
      else if(word == "O(printer")
      {
        cycle.cycleTime = checkDescript(cycles,data,"Printer");
        if(cycle.cycleTime <= 0)
          std::cerr << "Error in cycle time for: " << word << ")" << endl;
        else
        {
          cycle.id = word;
          metaCycles.push_back(cycle);
        }
      }

      else
        {
          std::cerr << "Mispelling or invalid descriptor in Meta data file: '" << word << ")', skipping process\n";
          data.erase(data.begin());
        }
        
  }
  /**check for end descriptors **/

  if(!startStack.empty())
  {
    std::cerr << "Warning: Meta file contains S(start) without an S(end)\n";
  }
  if(!endStack.empty())
  {
    std::cerr << "Warning: Meta file contains A(start) without an A(end)\n";
  }

  return metaCycles;
      

}//ends getMetaData

/** outputs data based on configuration file
  /*@pre configuration file has been handled
  /*@post all data is outputed based on config file 
  /*param bool logToFile, logToMon logs to file or monitor based on config file
  /*  vector to output data
  /*  string outfile name of the file to log to if needed
  */
bool ReadData:: outputCfgData(const std::vector<cycleInfo>& cycles, bool logToFile, bool logToMon, std::string outFile) const
{
  std::ofstream fout;
  //if it is to be logged to both monitor and file
  if(logToMon == true && logToFile == true)
  {
    fout.open(outFile);
    if (!fout.is_open())//tries to open files
    { 
      std::cerr<<"Could not open output file, printing only to monitor" << std::endl;
      cout << "Configuration File Data" << endl;
      for(int i = 0; i < cycles.size(); i++)
      {
        cout << cycles[i].id << " = " << cycles[i].cycleTime
        << " ms/cycle\n";
      }
      cout << "logged to monitor only because of issue opening file\n\n";
      return false;
    }//ends if
    else
       { 
        cout << "Configuration File Data" << endl;
        fout << "Configuration File Data" << endl;
         for(int i = 0; i < cycles.size(); i++)
          {
           cout << cycles[i].id << " = " << cycles[i].cycleTime
           << " ms/cycle\n";
           fout << cycles[i].id << " = " << cycles[i].cycleTime
           << " ms/cycle\n";
          } 
          cout<< "Logged to: Monitor and " << outFile << endl << endl;
          fout<< "Logged to: Monitor and " << outFile << endl << endl;
          fout.close();
          return true;
        }
    }//ends if supposed to be logged to mon and file

    //log to moitor only
    else if(logToMon == true && logToFile == false)
    {
      cout << "Configuration File Data" << endl;
      for(int i = 0; i < cycles.size(); i++)
      {
       cout << cycles[i].id << " = " << cycles[i].cycleTime
       << " ms/cycle\n";
      } 
      cout << "Logged to: Monitor only\n" << endl;
      return true;
    }//ends log to monitor only
    //log to file only
    else if(logToMon == false && logToFile == true)
    {
      fout.open(outFile);
      if (!fout.is_open())//tries to open files
      { 
        std::cerr<<"Could not open output file, aborting print" << std::endl;
        return false;
      }
      else
      {
        fout << "Configuration File Data" << endl;
        for(int i = 0; i < cycles.size(); i++)
        {
          fout << cycles[i].id << " = " << cycles[i].cycleTime
          << " ms/cycle\n";
        } 
        fout<< "Logged to: " << outFile << endl << endl;
        fout.close();
        return true;
      }
    }//ends log to file only

    else 
    {
      std::cerr<< "Invalid path to log Configuration data" << endl;
      return false;
    }
}//end outoutCfgdata

  /** outputs data based on configuration and meta file
  /*@pre configuration and meta files have been handled
  /*@post all data is outputed based on files 
  /*param bool logToFile, logToMon logs to file or monitor based on config file
  /*  vector to output data
  /*  string outfile name of the file to log to if needed
  */
bool ReadData:: outputMeta(const std::vector<cycleInfo>& cycles, bool logToFile, bool logToMon, std::string outFile) const
{
  std::ofstream fout;

  if(logToMon == true && logToFile == true)
  {
    fout.open(outFile, std::ios_base::app);
    if (!fout.is_open())//tries to open files
    { 
      std::cerr<<"Could not open output file, printing only to monitor" << std::endl;
      cout << "\nMeta Data Metrics" << endl;
      for(int i = 0; i < cycles.size(); i++)
      {
        cout << cycles[i].id << ") - " << cycles[i].cycleTime
        << " ms\n";
      }
      return false;
    }//ends if

    else
       { 
        cout << "\nMeta Data Metrics" << endl;
        fout << "\nMeta Data Metrics" << endl;
         for(int i = 0; i < cycles.size(); i++)
          {
           cout << cycles[i].id << ") = " << cycles[i].cycleTime
           << " ms\n";
           fout << cycles[i].id << ") = " << cycles[i].cycleTime
           << " ms\n";
          } 
          fout.close();
          return true;
        }
    }//ends if supposed to be logged to mon and file

    else if(logToMon == true && logToFile == false)
    {
      cout << "\nMeta Data Metrics" << endl;
      for(int i = 0; i < cycles.size(); i++)
      {
       cout << cycles[i].id << ") = " << cycles[i].cycleTime
       << " ms\n";
      } 
      return true;
    }

    else if(logToMon == false && logToFile == true)
    {
      fout.open(outFile, std::ios_base::app );
      if (!fout.is_open())//tries to open files
      { 
        std::cerr<<"Could not open output file, aborting print" << std::endl;
        return false;
      }
      else
      {
        fout << "\nMeta Data Metrics" << endl;
        for(int i = 0; i < cycles.size(); i++)
        {
          fout << cycles[i].id << ") = " << cycles[i].cycleTime
          << " ms\n";
        } 
        fout.close();
        return true;
      }
    }
    else 
    {
      std::cerr<< "Invalid path to log Configuration data" << endl;
      return false;
    }
}//ends output meta data
